import "./bootstrap";
import { createApp } from "vue";
import App from "../src/App.vue";

import.meta.glob(["../images/**", "../fonts/**"]);

// createApp(App).mount("#app");
